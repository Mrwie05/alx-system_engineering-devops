New readme for new project.
